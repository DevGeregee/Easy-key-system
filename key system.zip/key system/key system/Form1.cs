﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace key_system
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == new WebClient().DownloadString("Yaptgınız Key Link Github Pastebin Çalşıyor...") || textBox1.Text == "pırt")  ///textBox1.Text == "Admine Özel şifre!! İsdedginizi Yazın")
            {
                MessageBox.Show("Kullandığınız için teşekkür ederiz (istismar adınız)!");
                this.Hide();
                executer main = new executer();
                main.Show();

            }
            else
            {
                MessageBox.Show("Maalesef anahtar geçersiz. Tekrar deneyin.", "Anahtar Geçersiz");
                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Process.Start("https://raw.githubusercontent.com/ProtectorX22dasd/Key-Sytem/main/key.txt");  /// Process.Start("Yaptgınız Key Link Git Hub Pastebin Çalşıyor... ");
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
